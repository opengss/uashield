<template>
  <q-page class="row items-center justify-evenly bg-grey-10 text-white">
    <q-card class="bg-grey-10 full-card">
      <q-card-section>
        <div class="text-h4 text-center">BRUTE FORCE NOT IMPLEMENTED</div>
      </q-card-section>
    </q-card>
  </q-page>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'BruteForce'
})
</script>

<style lang="sass" scoped>
.full-card
  width: 80%
  max-width: 700pxa
</style>
